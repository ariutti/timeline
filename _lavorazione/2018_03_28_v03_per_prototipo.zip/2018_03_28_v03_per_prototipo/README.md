# README

Sketch preliminare che utilizza 35 LEDs e prossimità in vista dell'incontro con i clienti.
i pad capacitivi sono 7 e via seriale viene stampato un indice corrispondente al pad attivo (al momento solo se c'è una pressione).
